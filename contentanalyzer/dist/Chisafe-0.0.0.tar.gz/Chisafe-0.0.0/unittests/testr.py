from ContentAnalyzer import ContentAnalyzer
c = ContentAnalyzer()
p = open('test.html').read()
c.Classify_1("ID",p,["http://www.xvideos.com"])

