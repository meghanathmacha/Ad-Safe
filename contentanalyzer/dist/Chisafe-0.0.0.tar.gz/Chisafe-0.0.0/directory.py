import os
def path():
    import contentanalyzer
    path = os.path.dirname(contentanalyzer.__file__)
    return path    
